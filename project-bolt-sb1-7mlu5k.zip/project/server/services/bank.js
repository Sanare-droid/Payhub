import axios from 'axios';
import dotenv from 'dotenv';
import Payment from '../models/Payment.js';

dotenv.config();

const BANK_API_URL = process.env.BANK_API_URL;
const BANK_API_KEY = process.env.BANK_API_KEY;

export async function initiateBankTransfer(payment) {
  try {
    const response = await axios.post(
      `${BANK_API_URL}/transfers/initiate`,
      {
        amount: payment.amount,
        currency: payment.currency,
        reference: payment._id,
        accountName: payment.customer.name,
        accountNumber: payment.customer.bankAccount,
        bankCode: payment.customer.bankCode,
        narration: 'Payment for services',
        callbackUrl: `${process.env.API_URL}/api/webhooks/bank-transfer`,
      },
      {
        headers: {
          Authorization: `Bearer ${BANK_API_KEY}`,
        },
      }
    );

    return response.data;
  } catch (error) {
    throw new Error('Failed to initiate bank transfer');
  }
}

export async function processBankCallback(callbackData) {
  try {
    const { reference, status, transactionId } = callbackData;
    
    const payment = await Payment.findById(reference);
    if (!payment) {
      throw new Error('Payment not found');
    }

    payment.status = status === 'successful' ? 'completed' : 'failed';
    payment.bankReference = transactionId;
    payment.metadata = {
      ...payment.metadata,
      bankCallback: callbackData,
    };

    await payment.save();
    return payment;
  } catch (error) {
    throw new Error('Failed to process bank callback');
  }
}