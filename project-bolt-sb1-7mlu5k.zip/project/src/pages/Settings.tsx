import React, { useState } from 'react';
import { Shield, Star, Zap } from 'lucide-react';

const plans = [
  {
    name: 'Basic',
    price: 'Free',
    features: [
      'Up to 100 transactions/month',
      'Basic reporting',
      'Email support',
      'Standard processing time'
    ],
    icon: Shield,
    current: true
  },
  {
    name: 'Premium',
    price: '$49',
    features: [
      'Unlimited transactions',
      'Advanced analytics',
      'Priority support',
      'Custom branding',
      'Lower transaction fees'
    ],
    icon: Star,
    popular: true
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    features: [
      'Custom integration',
      'Dedicated support',
      'Volume discounts',
      'SLA guarantees',
      'API access'
    ],
    icon: Zap
  }
];

export function Settings() {
  const [currentPlan, setCurrentPlan] = useState('Basic');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Subscription Settings</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div
            key={plan.name}
            className={`relative bg-white rounded-lg shadow-sm p-6 border-2 
              ${currentPlan === plan.name ? 'border-indigo-600' : 'border-transparent'}`}
          >
            {plan.popular && (
              <div className="absolute top-0 right-0 -translate-y-1/2 px-3 py-1 bg-indigo-600 text-white text-sm font-medium rounded-full">
                Popular
              </div>
            )}
            
            <div className="flex items-center justify-center w-12 h-12 bg-indigo-50 rounded-lg mb-4">
              <plan.icon className="w-6 h-6 text-indigo-600" />
            </div>
            
            <h3 className="text-lg font-semibold text-gray-900">{plan.name}</h3>
            <p className="mt-2 text-2xl font-bold text-gray-900">{plan.price}</p>
            {plan.price !== 'Custom' && <p className="text-sm text-gray-500">/month</p>}
            
            <ul className="mt-6 space-y-4">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 shrink-0" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="ml-3 text-sm text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>

            <button
              onClick={() => setCurrentPlan(plan.name)}
              className={`mt-8 w-full px-4 py-2 rounded-lg text-sm font-medium
                ${currentPlan === plan.name
                  ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                  : 'bg-white text-indigo-600 border border-indigo-600 hover:bg-indigo-50'
                }`}
            >
              {currentPlan === plan.name ? 'Current Plan' : 'Upgrade Plan'}
            </button>
          </div>
        ))}
      </div>

      <div className="mt-12 bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Transaction Fees</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="text-sm text-gray-600">Local Transactions</p>
            <p className="text-2xl font-semibold text-gray-900">
              {currentPlan === 'Basic' ? '2.9%' : currentPlan === 'Premium' ? '2.4%' : '1.9%'}
              <span className="text-sm text-gray-500 ml-1">+ KES 30</span>
            </p>
          </div>
          <div className="space-y-2">
            <p className="text-sm text-gray-600">International Transactions</p>
            <p className="text-2xl font-semibold text-gray-900">
              {currentPlan === 'Basic' ? '3.9%' : currentPlan === 'Premium' ? '3.4%' : '2.9%'}
              <span className="text-sm text-gray-500 ml-1">+ KES 100</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}