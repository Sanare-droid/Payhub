import currency from 'currency.js';

export const supportedCurrencies = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'KES', symbol: 'KES', name: 'Kenyan Shilling' },
  { code: 'NGN', symbol: '₦', name: 'Nigerian Naira' },
  { code: 'ZAR', symbol: 'R', name: 'South African Rand' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
] as const;

export type CurrencyCode = typeof supportedCurrencies[number]['code'];

export function formatCurrency(amount: number, currencyCode: CurrencyCode): string {
  const currencyInfo = supportedCurrencies.find(c => c.code === currencyCode);
  if (!currencyInfo) throw new Error(`Unsupported currency: ${currencyCode}`);

  return currency(amount, { symbol: currencyInfo.symbol }).format();
}

export function getExchangeRate(from: CurrencyCode, to: CurrencyCode): Promise<number> {
  return fetch(`https://api.exchangerate-api.com/v4/latest/${from}`)
    .then(response => response.json())
    .then(data => data.rates[to]);
}