import React, { useState } from 'react';
import { PaymentMethodSelector } from './PaymentMethodSelector';
import { QRCodePayment } from './QRCodePayment';
import { MobileMoneyPayment } from './MobileMoneyPayment';
import { CardPayment } from './CardPayment';
import { BankTransferPayment } from './BankTransferPayment';
import { type CurrencyCode } from '../utils/currency';

interface NewPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NewPaymentModal({ isOpen, onClose }: NewPaymentModalProps) {
  const [amount, setAmount] = useState<number>(0);
  const [selectedMethod, setSelectedMethod] = useState('card');
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>('USD');

  if (!isOpen) return null;

  const renderPaymentMethod = () => {
    switch (selectedMethod) {
      case 'card':
        return <CardPayment amount={amount} currency={selectedCurrency} />;
      case 'mobile':
        return <MobileMoneyPayment amount={amount} currency={selectedCurrency} />;
      case 'qr':
        return <QRCodePayment amount={amount} currency={selectedCurrency} />;
      case 'bank':
        return <BankTransferPayment amount={amount} currency={selectedCurrency} />;
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">New Payment</h2>
        </div>

        <div className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Amount
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          <PaymentMethodSelector
            selectedMethod={selectedMethod}
            onMethodSelect={setSelectedMethod}
            selectedCurrency={selectedCurrency}
            onCurrencySelect={setSelectedCurrency}
          />

          <div className="mt-6">
            {renderPaymentMethod()}
          </div>
        </div>

        <div className="p-6 border-t border-gray-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}