import React from 'react';
import { Link } from 'react-router-dom';
import { LayoutDashboard, CreditCard, Activity, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed top-0 left-0 h-screen w-64 bg-white border-r border-gray-200">
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-gray-200">
            <h1 className="text-2xl font-bold text-indigo-600">PayHub</h1>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            <Link to="/dashboard" className="flex items-center px-4 py-2 text-gray-700 hover:bg-indigo-50 rounded-lg">
              <LayoutDashboard className="w-5 h-5 mr-3" />
              Dashboard
            </Link>
            <Link to="/payments" className="flex items-center px-4 py-2 text-gray-700 hover:bg-indigo-50 rounded-lg">
              <CreditCard className="w-5 h-5 mr-3" />
              Payments
            </Link>
            <Link to="/analytics" className="flex items-center px-4 py-2 text-gray-700 hover:bg-indigo-50 rounded-lg">
              <Activity className="w-5 h-5 mr-3" />
              Analytics
            </Link>
            <Link to="/settings" className="flex items-center px-4 py-2 text-gray-700 hover:bg-indigo-50 rounded-lg">
              <Settings className="w-5 h-5 mr-3" />
              Settings
            </Link>
          </nav>

          {/* User */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
                  <span className="text-indigo-600 font-medium">
                    {user?.name?.[0] || 'U'}
                  </span>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-700">{user?.name || 'User'}</p>
                  <p className="text-xs text-gray-500">{user?.email || 'user@example.com'}</p>
                </div>
              </div>
              <button
                onClick={logout}
                className="p-2 text-gray-400 hover:text-gray-600"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64 p-8">
        {children}
      </main>
    </div>
  );
}