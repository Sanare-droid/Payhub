import React, { useState } from 'react';
import { Building2, Copy } from 'lucide-react';
import { type CurrencyCode, formatCurrency } from '../utils/currency';

interface BankTransferPaymentProps {
  amount: number;
  currency: CurrencyCode;
}

interface BankDetails {
  bankName: string;
  accountNumber: string;
  swiftCode: string;
  reference: string;
}

const bankDetailsByRegion: Record<string, BankDetails> = {
  EU: {
    bankName: 'Deutsche Bank',
    accountNumber: 'DE89 3704 0044 0532 0130 00',
    swiftCode: 'DEUTDEFF',
    reference: `PAY-${Date.now()}`,
  },
  US: {
    bankName: 'Chase Bank',
    accountNumber: '000123456789',
    swiftCode: 'CHASUS33',
    reference: `PAY-${Date.now()}`,
  },
  UK: {
    bankName: 'Barclays',
    accountNumber: '20-00-00 12345678',
    swiftCode: 'BARCGB22',
    reference: `PAY-${Date.now()}`,
  },
};

export function BankTransferPayment({ amount, currency }: BankTransferPaymentProps) {
  const [region, setRegion] = useState('EU');
  const [copied, setCopied] = useState('');

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopied(field);
    setTimeout(() => setCopied(''), 2000);
  };

  const bankDetails = bankDetailsByRegion[region];

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Select Region
        </label>
        <select
          value={region}
          onChange={(e) => setRegion(e.target.value)}
          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
        >
          <option value="EU">European Union</option>
          <option value="US">United States</option>
          <option value="UK">United Kingdom</option>
        </select>
      </div>

      <div className="bg-gray-50 p-6 rounded-lg space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-500">Amount to Pay</p>
            <p className="text-lg font-semibold text-gray-900">
              {formatCurrency(amount, currency)}
            </p>
          </div>
          <Building2 className="h-8 w-8 text-gray-400" />
        </div>

        {Object.entries(bankDetails).map(([key, value]) => (
          <div key={key} className="flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-gray-500">{key}</p>
              <p className="text-sm font-mono text-gray-900">{value}</p>
            </div>
            <button
              onClick={() => copyToClipboard(value, key)}
              className="p-2 text-gray-400 hover:text-gray-600"
            >
              <Copy className={`h-5 w-5 ${copied === key ? 'text-green-500' : ''}`} />
            </button>
          </div>
        ))}
      </div>

      <div className="text-sm text-gray-500">
        <p>Please include the reference number in your transfer description.</p>
        <p>The payment will be credited to your account once we receive it.</p>
      </div>
    </div>
  );
}