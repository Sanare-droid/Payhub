import React, { useState } from 'react';
import { Phone } from 'lucide-react';
import { type CurrencyCode, formatCurrency } from '../utils/currency';

interface MobileMoneyPaymentProps {
  amount: number;
  currency: CurrencyCode;
}

interface Provider {
  id: string;
  name: string;
  countries: string[];
  logo: string;
}

const mobileMoneyProviders: Provider[] = [
  {
    id: 'mpesa',
    name: 'M-PESA',
    countries: ['KEN', 'TZA', 'GHA'],
    logo: 'https://res.cloudinary.com/demo/image/upload/mpesa_logo.png'
  },
  {
    id: 'airtel',
    name: 'Airtel Money',
    countries: ['KEN', 'UGA', 'TZA', 'RWA', 'NGA'],
    logo: 'https://res.cloudinary.com/demo/image/upload/airtel_logo.png'
  },
  {
    id: 'mtn',
    name: 'MTN Mobile Money',
    countries: ['GHA', 'UGA', 'RWA', 'ZAF'],
    logo: 'https://res.cloudinary.com/demo/image/upload/mtn_logo.png'
  },
];

export function MobileMoneyPayment({ amount, currency }: MobileMoneyPaymentProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [selectedProvider, setSelectedProvider] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Implement mobile money payment logic here
    console.log('Processing mobile money payment:', { amount, currency, phoneNumber, selectedProvider });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        {mobileMoneyProviders.map((provider) => (
          <button
            key={provider.id}
            onClick={() => setSelectedProvider(provider.id)}
            className={`p-4 border rounded-lg text-center ${
              selectedProvider === provider.id
                ? 'border-indigo-600 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-200'
            }`}
          >
            <img
              src={provider.logo}
              alt={provider.name}
              className="h-8 mx-auto mb-2"
            />
            <span className="text-sm font-medium text-gray-900">
              {provider.name}
            </span>
          </button>
        ))}
      </div>

      {selectedProvider && (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phone Number
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Enter your phone number"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Pay {formatCurrency(amount, currency)}
          </button>
        </form>
      )}
    </div>
  );
}