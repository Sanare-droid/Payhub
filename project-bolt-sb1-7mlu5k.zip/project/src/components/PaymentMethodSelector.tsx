import React from 'react';
import { CreditCard, Smartphone, QrCode, Globe } from 'lucide-react';
import { supportedCurrencies, type CurrencyCode } from '../utils/currency';

interface PaymentMethodSelectorProps {
  selectedMethod: string;
  onMethodSelect: (method: string) => void;
  selectedCurrency: CurrencyCode;
  onCurrencySelect: (currency: CurrencyCode) => void;
}

export function PaymentMethodSelector({
  selectedMethod,
  onMethodSelect,
  selectedCurrency,
  onCurrencySelect,
}: PaymentMethodSelectorProps) {
  const paymentMethods = [
    { id: 'card', name: 'Card', icon: CreditCard },
    { id: 'mobile', name: 'Mobile Money', icon: Smartphone },
    { id: 'qr', name: 'QR Code', icon: QrCode },
    { id: 'bank', name: 'Bank Transfer', icon: Globe },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {paymentMethods.map((method) => (
          <button
            key={method.id}
            onClick={() => onMethodSelect(method.id)}
            className={`flex items-center p-4 rounded-lg border ${
              selectedMethod === method.id
                ? 'border-indigo-600 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-200'
            }`}
          >
            <method.icon className="w-5 h-5 mr-3 text-indigo-600" />
            <span className="text-sm font-medium text-gray-900">{method.name}</span>
          </button>
        ))}
      </div>

      <div className="mt-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Select Currency
        </label>
        <select
          value={selectedCurrency}
          onChange={(e) => onCurrencySelect(e.target.value as CurrencyCode)}
          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
        >
          {supportedCurrencies.map((currency) => (
            <option key={currency.code} value={currency.code}>
              {currency.code} - {currency.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}